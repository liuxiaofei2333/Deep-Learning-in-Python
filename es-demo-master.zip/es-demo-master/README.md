# es-demo
基于springboot2.x elasticsearch 6.6.2 HighLevelRESTClient  的demo
环境: jdk1.8 elasticsearch:6.6.2(已安装 ik 分词器插件)  HighLevelRESTClient:6.6.2
