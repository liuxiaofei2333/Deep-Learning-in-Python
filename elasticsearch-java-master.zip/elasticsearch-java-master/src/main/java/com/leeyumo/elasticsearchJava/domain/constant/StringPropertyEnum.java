package com.leeyumo.elasticsearchJava.domain.constant;

public interface StringPropertyEnum {
    String getValue();
}
