package com.michael.demoelasticsearch.service;

import com.alibaba.fastjson.JSON;
import org.apache.http.HttpHost;
import org.elasticsearch.action.ActionListener;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.RestClient;
import org.elasticsearch.client.RestHighLevelClient;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Map;

/**
 * @author Michael
 * @create 2019-05-05 23:35
 */
@Service
public class ElasticsearchService {
    private RestHighLevelClient client;

    public ElasticsearchService() {
        client = new RestHighLevelClient(
                RestClient.builder(
                        new HttpHost("192.168.3.43", 9200, "http")));
    }

    // https://www.elastic.co/guide/en/elasticsearch/client/java-rest/7.0/java-rest-high-document-index.html

    public void addData(String index, Object obj) {
        // 创建索引
        IndexRequest request = new IndexRequest(index);
        // 准备文档数据
        String jsonStr = JSON.toJSONString(obj);
        // 转成 MAP
        Map<String, Object> jsonMap = JSON.parseObject(jsonStr, Map.class);
        jsonMap.put("createdAt", new Date());
        //Document source provided as a Map which gets automatically converted to JSON format
        request.source(jsonMap);

        client.indexAsync(request, RequestOptions.DEFAULT, new ActionListener<IndexResponse>() {
            @Override
            public void onResponse(IndexResponse indexResponse) {

            }

            @Override
            public void onFailure(Exception e) {

            }
        });
    }
}
