package com.michael.demoelasticsearch.constants;

/**
 * @author Michael
 * @create 2019-05-05 22:36
 */
public enum UserSexEnum {
    /*
     * 性别，男 女
     * */
    MAN,WOMAN
}
