package com.michael.demoelasticsearch.config;

import org.springframework.context.annotation.Configuration;

import javax.annotation.PostConstruct;

/**
 * @author Michael
 * @create 2019-05-05 22:51
 */

@Configuration
public class ElasticsearchConfig {
    @PostConstruct
    public void init(){

    }
}
