package com.michael.springbootdruid.constants;

/**
 * @author Michael
 * @create 2019-04-12 22:42
 */
public enum UserSexEnum {
    /*
     * 性别，男 女
     * */
    MAN,WOMAN
}
