package com.michael.springbootdruid;

import com.michael.springbootdruid.mapper.UserMapper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
public class SpringBootDruidApplication {
    @Autowired
    private UserMapper userMapper;

    private static final Logger logger = LogManager.getLogger(SpringBootDruidApplication.class);
    public static void main(String[] args) {
        logger.debug("Debugging log");
        logger.info("Info log");
        logger.warn("Hey, This is a warning!");
        logger.error("Oops! We have an Error. OK");
        logger.fatal("Damn! Fatal error. Please fix me.");
        SpringApplication.run(SpringBootDruidApplication.class, args);
    }

}
