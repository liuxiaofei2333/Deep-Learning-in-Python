package com.michael.demoh2;

import com.sun.webkit.ContextMenu;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;

@SpringBootApplication
@Slf4j
public class DemoH2Application implements CommandLineRunner {
    @Autowired
    private DataSource dataSource;

    public static void main(String[] args) {
        SpringApplication.run(DemoH2Application.class, args);
    }

    @Override
    public void run(String... args) throws Exception{
        showConnection();
    }

    private void showConnection() throws SQLException {
        long start = System.currentTimeMillis();
        for (int i = 0; i < 1000; i++) {
            log.info(dataSource.toString());
            Connection conn = dataSource.getConnection();
            log.info(conn.toString());
            conn.close();
        }
        long end = System.currentTimeMillis();
        System.out.println("获取1000个连接用时："+(end-start));

    }

}
