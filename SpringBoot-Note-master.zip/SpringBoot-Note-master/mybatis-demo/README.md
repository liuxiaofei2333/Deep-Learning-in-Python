# MyBatis+Swagger+log4j2 学习

## Mybatis
- [Spring Boot(六)：如何优雅的使用 Mybatis](https://mp.weixin.qq.com/s?__biz=MzU3NzczMTAzMg==&mid=2247483694&idx=1&sn=8b87b7aff61f3b54014e1c3f7390fae1&chksm=fd016199ca76e88f559ae2ca7c82ca7bb37aebb6ccac22e787f4642821c7961486a52f179284&mpshare=1&scene=1&srcid=0315t1iDdWAwNR2IUuG0goLF#rd)

## Swagger
- [王磊的博客-Spring Boot（九）Swagger2自动生成接口文档和Mock模拟数据](http://www.apigo.cn/2018/09/01/Spring-Boot%EF%BC%88%E4%B9%9D%EF%BC%89Swagger2%E8%87%AA%E5%8A%A8%E7%94%9F%E6%88%90%E6%8E%A5%E5%8F%A3%E6%96%87%E6%A1%A3%E5%92%8CMock%E6%A8%A1%E6%8B%9F%E6%95%B0%E6%8D%AE/)
- [程序猿‍DD-Spring Boot中使用Swagger2构建强大的RESTful API文档](http://blog.didispace.com/springbootswagger2/)
- [简书-Swagger Annotation 详解（建议收藏）](https://www.jianshu.com/p/b0b19368e4a8)
- [CSDN-swagger2注解详细说明](https://blog.csdn.net/qq_28009065/article/details/79104103)

## LOG4J2

Java 中比较常用的日志工具类，有：
- Log4j、
- SLF4j、
- Commons-logging（简称jcl）、
- Logback、
- Log4j2（Log4j 升级版）、
- Jdk Logging

Spring Boot 默认使用 Logback，但相比较而言，Log4j2 在性能上面会更好。spring-boot高版本都不再支持log4j,而是支持log4j2


### FAQ

```shell
Configuration has multiple incompatible Appenders pointing to the same resource 'logs/mybatis-demo-warn.log'
```


- [博客园-田园里的蟋蟀-Spring Boot 使用 Log4j2](https://www.cnblogs.com/xishuai/p/spring-boot-log4j2.html)
- [掘金-zdran-Spring Boot 学习笔记(二) 整合 log4j2](https://juejin.im/entry/5b35f1e86fb9a00e315c330e)
- [王磊的博客-Spring Boot（十）Logback和Log4j2集成与日志发展史](http://www.apigo.cn/2018/09/03/Spring-Boot%EF%BC%88%E5%8D%81%EF%BC%89%E6%97%A5%E5%BF%97Logback%E5%92%8CLog4j2%E9%9B%86%E6%88%90%E4%B8%8E%E6%97%A5%E5%BF%97%E5%8F%91%E5%B1%95%E5%8F%B2/)
- [SpringBoot + Log4j2使用配置](https://www.jianshu.com/p/46b530446d20) 异步日志介绍的比较多