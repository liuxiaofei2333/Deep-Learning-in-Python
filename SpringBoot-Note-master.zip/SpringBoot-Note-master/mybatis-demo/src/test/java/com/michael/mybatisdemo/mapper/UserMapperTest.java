package com.michael.mybatisdemo.mapper;

import com.michael.mybatisdemo.constants.UserSexEnum;
import com.michael.mybatisdemo.model.UserEntity;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.List;

/**
 * @author Michael
 * @create 2019-03-17 13:18
 */
@RunWith(SpringRunner.class)
@SpringBootTest
public class UserMapperTest {
    @Autowired
    private UserMapper userMapper;


    @Test
    public void testInsert() throws Exception {
        int beforeInsert = userMapper.getAll().size();
        userMapper.insert(new UserEntity("aa1", "a123456", UserSexEnum.MAN, "aaa"));
        userMapper.insert(new UserEntity("bb1", "b123456", UserSexEnum.WOMAN, "bbb"));
        userMapper.insert(new UserEntity("cc1", "b123456", UserSexEnum.WOMAN, "ccc"));
        int afterInsert = userMapper.getAll().size();

        Assert.assertEquals(3, afterInsert-beforeInsert);
    }

    @Test
    public void testQuery() throws Exception {
        List<UserEntity> users = userMapper.getAll();
        System.out.println(users.toString());
    }


    @Test
    public void testUpdate() throws Exception {
        UserEntity user = userMapper.getOne(1L);
        long id = user.getId();
        System.out.println(user.toString());
        user.setNickName("neo");
        userMapper.update(user);
        Assert.assertTrue(("neo".equals(userMapper.getOne(1L).getNickName())));
    }

}
