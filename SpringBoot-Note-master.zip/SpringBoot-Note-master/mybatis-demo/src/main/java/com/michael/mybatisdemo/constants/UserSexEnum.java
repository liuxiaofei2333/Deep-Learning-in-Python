package com.michael.mybatisdemo.constants;

/**
 * @author Michael
 * @create 2019-03-17 11:24
 */
public enum UserSexEnum {
    /*
    * 性别，男 女
    * */
    MAN,WOMAN
}
