package com.michael.mybatisdemo.controller;

import com.michael.mybatisdemo.MybatisDemoApplication;
import com.michael.mybatisdemo.mapper.UserMapper;
import com.michael.mybatisdemo.model.UserEntity;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

import javax.websocket.server.PathParam;
import java.util.List;

/**
 * @author Michael
 * @create 2019-03-17 11:45
 */
@RestController
@RequestMapping("/api/v1/user")
// api-value：定义名称，如果没有定义，则默认显示类名
@Api(value = "Swagger User Controller", description = "演示Swagger用法的Control类", tags = "用户Controller")
public class UserController {
    @Autowired
    private UserMapper userMapper;
    @Value("${ENV_NAME}")
    public String envName;

    private static final Logger logger = LogManager.getLogger(UserController.class);



    @ApiOperation(value = "测试", notes = "测试返回")
    @RequestMapping(value = "/test",method = RequestMethod.GET)
    public String index() {
        logger.error("This is 测试！ error");
        return "Hello, Michael";
    }

    @ApiOperation(value = "获取用户列表", notes = "获取全部用户信息")
    @RequestMapping(value = "/getUsers", method = RequestMethod.GET)
    public List<UserEntity> getUsers() {
        List<UserEntity> users = userMapper.getAll();
        logger.info("This is iofo: "+users);
        return users;
    }

    @ApiOperation(value = "存储用户信息", notes = "存储用户详细信息")
    @RequestMapping(value = "", method = RequestMethod.POST)
    public void saveUser(@RequestBody UserEntity user) {
        logger.debug("This is debug: "+user);
        userMapper.insert(user);
    }

    @ApiOperation(value = "删除用户", notes = "根据用户id删除用户信息")
    @ApiImplicitParam(name = "id", value = "用户id",paramType = "path")
    @RequestMapping(value = "/{id}", method = RequestMethod.DELETE)
    public void deleteUser(@PathVariable("id") Long id) {
        logger.warn("Your are deleting ,attention: "+id);
        userMapper.delete(id);
    }


    @ApiOperation(value = "更新用户信息", notes = "更新用户的个人信息")
    @PutMapping
    public void updateUser(@RequestBody UserEntity user) {
        logger.warn("Warning: You are updating user info");
        userMapper.update(user);
    }

    @ApiOperation(value = "查询单用户", notes = "根据用户id 查询其信息")
    @ApiImplicitParam(name = "id", value = "用户id",paramType = "query",dataType = "Long")
    @GetMapping
    public UserEntity getUser(@PathParam("id") Long id) {

        logger.info("Info log 查询用户信息，用户 ID："+id);
        UserEntity user = userMapper.getOne(id);
        return user;
    }


}
