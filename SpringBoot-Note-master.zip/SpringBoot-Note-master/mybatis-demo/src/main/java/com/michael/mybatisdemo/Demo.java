package com.michael.mybatisdemo;

/**
 * @author Michael
 * @create 2019-04-05 17:14
 */
public class Demo {
    private  String name;

    public static void main(String[] args) {
        String js = "hello";
        System.out.println(js);
    }

}
